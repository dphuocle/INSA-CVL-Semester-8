
Ces exercices stimuleront :
* Des sessions pratiques d'autodéfense où les employés seront formés à répondre aux menaces immédiates et à utiliser des équipements de sécurité personnels.

* Des scénarios de menaces variées pour tester la réaction et la résilience des employés sous pression.

* La distribution et l'utilisation correcte de manuels de procédure de sécurité et de dispositifs de protection personnelle lors de simulations d'attaques.


