
Les simulations incluront :
* La mise en œuvre d'un protocole d'urgence établi avec les autorités locales et tanzaniennes pour assurer une extraction efficace.

* Des exercices d'évacuation réguliers depuis les logements des expatriés pour peaufiner la coordination et réduire le temps de réaction.

* La validation de la disponibilité et de l'adéquation du nombre de véhicules nécessaires pour le transport de tous les expatriés, avec des plans d'urgence pour gérer un flux de 10 000 à 15 000 personnes.
