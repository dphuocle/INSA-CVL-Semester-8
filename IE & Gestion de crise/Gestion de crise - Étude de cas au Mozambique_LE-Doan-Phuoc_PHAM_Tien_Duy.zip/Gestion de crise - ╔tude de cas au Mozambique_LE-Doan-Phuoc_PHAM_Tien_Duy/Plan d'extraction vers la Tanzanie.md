
Face à la menace terroriste et à la proximité géographique de la Tanzanie, un plan d'extraction est primordial pour garantir la sécurité du personnel en cas d'escalade du conflit. La Tanzanie est un pays qui a de faibles risques d'attaques terroristes.

![[Tanzania.png]]

Étapes clés :

- Mise en place d'une route d'évacuation sécurisée vers la Tanzanie, avec des points de contrôle et de rassemblement prédéfinis.

![[Route to Tanzania.png]]

- Coordination avec les autorités tanzaniennes pour faciliter le passage sécurisé en cas d'urgence.
    
- Formation du personnel à l'évacuation d'urgence et exercices de simulation réguliers.
    
- Préparation de kits d'évacuation d'urgence pour tous les employés comprenant les nécessités de base et les informations de contact d'urgence.





