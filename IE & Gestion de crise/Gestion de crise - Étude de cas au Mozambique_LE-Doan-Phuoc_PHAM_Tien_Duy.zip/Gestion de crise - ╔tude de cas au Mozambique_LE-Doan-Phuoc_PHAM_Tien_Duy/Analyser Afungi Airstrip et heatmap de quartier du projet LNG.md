
En analysant ces circuits, il semble qu'il y ait un point central qui pourrait servir de point de départ ou d'arrivée pour ces courses. Il est plausible de supposer que le bâtiment à partir duquel les employés commencent leur course est l'hôtel réservé aux employés. Cette observation nous fournit des informations supplémentaires sur l'utilisation des bâtiments dans ce complexe. Nous pouvons ainsi identifier où se trouvent généralement les employés et où se concentre la plus forte densité d'activité.

![[Afungi and heatmap.png]]
