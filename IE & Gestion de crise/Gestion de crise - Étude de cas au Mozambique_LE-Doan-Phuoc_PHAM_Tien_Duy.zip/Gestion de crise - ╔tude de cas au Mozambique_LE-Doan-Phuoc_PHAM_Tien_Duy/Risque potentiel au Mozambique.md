Nous constatons que le Mozambique est une zone à haut risque, notamment en raison de la présence de pirates somaliens ou du terrorisme houthi. Étant donné que le site d'extraction se trouve près de la côte et de la mer, il existe une forte probabilité que les attaques surviennent par voie maritime, potentiellement menées par des pirates somaliens ou des groupes terroristes houthis venant de Yemen.

![[Risque Potentiel.png]]

